# Telegram Forward Bot FINAL (Word Block + Bulk)

## Features
- Auto forward new source channel posts
- Word block on new posts, manual forward, AND bulk
- Bulk: /bulk 1 12500
- Admin commands

## Railway
1. Upload ALL files in this folder to GitHub (not .env)
2. Railway → Deploy from GitHub
3. Add variables from RAILWAY_VARIABLES.txt
4. Wait until Active
5. /start /listblocks /bulk 1 20

## Commands
/start /status /test
/block word /unblock word /listblocks
/bulk FROM TO
/bulkstatus /bulkstop
/copy ID
